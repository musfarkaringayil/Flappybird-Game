﻿Public Class FlappyBird
    Dim moveRight As Boolean = False
    Dim moveLeft As Boolean = False
    Dim yspeed As Integer = 1                      ' <--- Bird up speed adjustment
    Dim gravity As Integer = 2                    ' <--- Bird down_gravity adjustment
    Dim topPipe(1) As PictureBox                     ' <--- TopPipe(1) "top pipe" assign as picturebox
    Dim pipeheight As Integer = 600                  ' <--- Pipe height adjustment
    Dim pipe(1) As PictureBox                        ' <--- pipe(1) "down pipe" assign as picturebox
    Dim gapbetweenPipes As Integer = 800             ' <--- Pipe Gap in between topPipe and downPipe
    Dim pipespeed As Single = 15                     ' <--- Pipe Speed to left side adjustment
    Dim groundspeed As Single = 4                    ' <--- Speed assign for Ground picturebox
    Dim intP As Integer = 0                          ' <--- Points
    Dim Sound As New Media.SoundPlayer               ' <--- Implemented Media Player to Play The Sound for nessecery attributes
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Sound.SoundLocation = "TapButton.wav"        ' <--- Sound loction For Main Menu Button Click 
        Sound.Play()                                 ' <--- Sound play would Take place
        If TextBox1.Text = "" Then                   ' <--- Sound
            MsgBox("Please enter the player name")   ' <--- main menu text box is black it will show the msgbox to "enter the name"
            TextBox1.Focus()
            Exit Sub
        End If
        Score.Text = 0
        intP = 0
        Dim XY As System.Drawing.Point
        XY.X = 56                                   '{
        XY.Y = 64
        bird.Location = XY                          '  <--- reset the location of the bird when restarts
        XY.X = 70
        XY.Y = 300                                  '}

        pipe(0).Top = 70 + 300 * Rnd()                '{
        pipe(0).Left = 600
        pipe(1).Top = 70 + 300 * Rnd()
        pipe(1).Left = 1100                           ' <--- Both top pipes and down pipes location is equal to reset here "so that when 'start game' button clicks it will reset location of pipes" 
        topPipe(0).Top = pipe(0).Top - gapbetweenPipes
        topPipe(0).Left = 600
        topPipe(1).Top = pipe(1).Top - gapbetweenPipes
        topPipe(1).Left = 1100                        '}
        PictureBox6.Visible = False
        PictureBox6.Enabled = False
        Button1.Visible = False
        Button1.Enabled = False
        Button2.Visible = False
        Button2.Enabled = False
        Button3.Visible = False
        Button3.Enabled = False
        Button4.Visible = False
        Button4.Enabled = False
        Label1.Visible = False
        Label1.Enabled = False
        Label2.Visible = False
        Label2.Enabled = False
        Label4.Visible = True
        TextBox1.Visible = False
        TextBox1.Enabled = False
        PictureBox2.Visible = True
        PictureBox2.Enabled = True
        PictureBox3.Visible = False
        PictureBox5.Visible = True
        PictureBox5.Enabled = True
        bird.Visible = True
        bird.Enabled = True
    End Sub
    Private Sub form1_load(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.P Then
            Timer1.Stop()
            Timer1.Enabled = False
            Label3.Visible = False
            Label3.Enabled = False
            Label4.Visible = True
            Label4.Enabled = True
        End If
        If e.KeyCode = Keys.S Then
            Timer1.Start()
            Timer1.Enabled = True
            PictureBox2.Visible = False
            PictureBox2.Enabled = False
            PictureBox5.Visible = False
            PictureBox5.Enabled = False
            Label3.Visible = True
            Label3.Enabled = True
            Label4.Visible = False
            Label4.Enabled = False
        End If
        Select Case e.KeyValue
            Case Keys.Right
                moveRight = True
                Sound.SoundLocation = "BirdMove.wav"
                Sound.Play()
            Case Keys.Left
                moveLeft = True
                Sound.SoundLocation = "BirdMove.wav"
                Sound.Play()
        End Select
        If e.KeyValue = Keys.Up Then
            yspeed = -15
            Sound.SoundLocation = "jump2.wav"
            Sound.Play()
        End If
    End Sub
    Private Sub FlappyBird_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        Select Case e.KeyValue
            Case Keys.Right
                moveRight = False
            Case Keys.Left
                moveLeft = False
        End Select
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.scoretable1' table. You can move, or remove it, as needed.
        Me.Scoretable1TableAdapter.Fill(Me.Database1DataSet.scoretable1)
        Timer2.Start()
        bird.Visible = False
        Timer1.Enabled = False
        Randomize()            ' <--- its for ramdomizing pipes height and down
        CreatePipes(1)         ' <--- Down pipe created here.
        CreateTopPipes(1)      ' <--- Top pipe created here.
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If moveRight = True And (bird.Left + bird.Width < Me.Width) Then
            bird.Left = bird.Left + 5
        End If
        If moveLeft = True Then
            bird.Left = bird.Left - 5
        End If
        yspeed += gravity
        bird.Top += yspeed
        For i = 0 To 1
            pipe(i).Left -= pipespeed
            topPipe(i).Left -= pipespeed
            PictureBox1.Left -= groundspeed
            If (Collision(pipe(i), bird) = True) Or (Collision(topPipe(i), bird) = True) Or (Collision(PictureBox1, bird) = True) Then
                Sound.SoundLocation = "DieSound.wav"
                Sound.Play()
                Timer1.Stop()
                Timer1.Enabled = False
                Label3.Visible = False
                Label3.Enabled = False
                PictureBox6.Visible = True
                PictureBox6.Enabled = True
                MessageBox.Show("Game Over" & vbNewLine & "Your Score: " & intP, "Game Over")
                PictureBox3.Visible = True
                PictureBox3.Enabled = True
                Button1.Visible = True
                Button1.Enabled = True
                Button2.Visible = True
                Button2.Enabled = True
                Button3.Visible = True
                Button3.Enabled = True
                Button4.Visible = True
                Button4.Enabled = True
           
                Dim STAT As Integer
                STAT = 0
                If (Me.Scoretable1TableAdapter.ScalarQuery(Me.TextBox1.Text)) Then
                    STAT = Me.Scoretable1TableAdapter.ScalarQuery(Me.TextBox1.Text)
                    Me.Scoretable1TableAdapter.UpdateQuery(Me.TextBox1.Text, Me.intP, STAT)
                Else
                    Me.Scoretable1TableAdapter.Insert(Me.TextBox1.Text, Me.intP)
                End If
                Me.Scoretable1TableAdapter.Fill(Me.Database1DataSet.scoretable1)
                Exit Sub
            End If
            If (pipe(i).Left < 0) Or (bird.Right = pipe(i).Left) Or (bird.Right = topPipe(i).Left) Then
                intP += 1
                pipe(i).Left += 800
                topPipe(i).Left += 800
                pipe(i).Top = 70 + 300 * Rnd()
                topPipe(i).Top = pipe(i).Top - gapbetweenPipes
                Score.Text = CStr(intP)
                Sound.SoundLocation = "PointSound.wav"
                Sound.Play()
            End If
            If PictureBox1.Left < -100 Then
                PictureBox1.Left += 450
                PictureBox1.Left = 0
            End If
        Next
    End Sub

    Private Sub CreatePipes(ByVal Number As Integer)
        Dim i As Integer = -100
        For i = 0 To Number
            Dim temp As New PictureBox
            Me.Controls.Add(temp)
            temp.Width = 85
            temp.Height = pipeheight
            temp.Load("d:\Downloads\Compressed\Fly Flappy Bird Assets\Pipe Modes\Pipe1.png")  ' <--- down pipe image
            temp.Top = 70 + 300 * Rnd()
            temp.Left = (i * 500) + 600
            PictureBox1.Left = (i * 0) + 0
            pipe(i) = temp
            pipe(i).Visible = True
        Next
    End Sub
    Private Sub CreateTopPipes(ByVal Number As Integer)
        Dim i As Integer = 0
        For i = 0 To Number
            Dim temp As New PictureBox
            Me.Controls.Add(temp)
            temp.Width = 85
            temp.Height = pipeheight
            temp.Load("d:\Downloads\Compressed\Fly Flappy Bird Assets\Pipe Modes\PipeD1.png") ' <--- top pipe image
            temp.Top = pipe(i).Top - gapbetweenPipes
            temp.Left = (i * 500) + 600
            topPipe(i) = temp
            topPipe(i).Visible = True
        Next
    End Sub
    Private Function Collision(ByVal Object1 As Object, ByVal Object2 As Object) As Boolean
        Dim collided As Boolean = False
        If Object1.Top + Object1.Height >= Object2.Top And _
            Object2.Top + Object2.Height >= Object1.Top And _
            Object1.Left + Object1.Width >= Object2.Left And _
            Object2.Left + Object2.Width >= Object1.Left And Object1.visible = True And Object2.visible = True Then
            collided = True
        End If
        Return collided
    End Function
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            ProgressBar1.Enabled = False
            ProgressBar1.Visible = False
            PictureBox4.Enabled = False
            PictureBox4.Visible = False
            Timer2.Stop()
            Timer1.Enabled = False
            PictureBox3.Visible = True
            PictureBox3.Enabled = True
            Button1.Visible = True
            Button1.Enabled = True
            Button4.Visible = True
            Button4.Enabled = True
            Button2.Visible = True
            Button2.Enabled = True
            Button3.Visible = True
            Button3.Enabled = True
            Button5.Enabled = False
            Button5.Visible = False
            TextBox1.Enabled = True
            TextBox1.Visible = True
            Label1.Enabled = True
            Label1.Visible = True
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Sound.SoundLocation = "TapButton.wav"
        Sound.Play()
        Label2.Visible = False
        Label2.Enabled = False
        DataGridView1.Visible = True
        Label1.Visible = False
        TextBox1.Visible = False
        TextBox1.Enabled = False
        Button1.Visible = False
        Button1.Enabled = False
        Button4.Visible = False
        Button4.Enabled = False
        Button2.Visible = False
        Button2.Enabled = False
        Button3.Visible = False
        Button3.Enabled = False
        Button5.Visible = True
        Button5.Enabled = True
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Sound.SoundLocation = "TapButton.wav"
        Sound.Play()
        DataGridView1.Visible = False
        Label2.Visible = True
        Label1.Visible = False
        TextBox1.Visible = False
        TextBox1.Enabled = False
        Button1.Visible = False
        Button1.Enabled = False
        Button4.Visible = False
        Button4.Enabled = False
        Button2.Visible = False
        Button2.Enabled = False
        Button3.Visible = False
        Button3.Enabled = False
        Button5.Visible = True
        Button5.Enabled = True
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Application.Exit()
    End Sub
    Private Sub Button5_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.MouseHover
        Button5.BackColor = Color.LightGreen
    End Sub
    Private Sub Button5_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.MouseLeave
        Button5.BackColor = Color.ForestGreen
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If Label2.Visible = True Or DataGridView1.Visible = True Then
            Label2.Visible = False
            Button1.Visible = True
            Button1.Enabled = True
            Button4.Visible = True
            Button4.Enabled = True
            Button2.Visible = True
            Button2.Enabled = True
            Button3.Visible = True
            Button3.Enabled = True
            TextBox1.Enabled = True
            TextBox1.Visible = True
            Label1.Enabled = True
            Label1.Visible = True
            Button5.Enabled = False
            Button5.Visible = False
            DataGridView1.Visible = False
        End If
    End Sub

    Private Sub PictureBox4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox4.Click

    End Sub
End Class
