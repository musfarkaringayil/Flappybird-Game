﻿Partial Class Database1DataSet
    Partial Class scoretable1DataTable

        Private Sub scoretable1DataTable_scoretable1RowChanging(ByVal sender As System.Object, ByVal e As scoretable1RowChangeEvent) Handles Me.scoretable1RowChanging

        End Sub

    End Class

End Class

Namespace Database1DataSetTableAdapters
    
    Partial Public Class scoretable1TableAdapter
    End Class
End Namespace
